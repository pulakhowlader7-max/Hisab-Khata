var CACHE = "hisab-shell-v29";
var PAGE = new URL("./", self.registration.scope).href;   // অ্যাপের মূল ঠিকানা (…/)
var ASSETS = ["./manifest.json", "./icon-512.png", "./icon-192.png",
              "./icon-maskable-512.png", "./icon-180.png", "./favicon-32.png"];
var LIB = "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2";

// রিডাইরেক্ট হওয়া উত্তর ক্যাশ থেকে পেজ হিসেবে দেওয়া যায় না (অফলাইনে খুলত না), তাই পরিষ্কার কপি বানানো হয়
function clean(r) {
  if (!r.redirected) return Promise.resolve(r);
  return r.blob().then(function (b) {
    return new Response(b, { status: 200, statusText: "OK", headers: r.headers });
  });
}
function savePage(r) {
  return clean(r).then(function (x) {
    return caches.open(CACHE).then(function (c) { return c.put(PAGE, x); });
  });
}

self.addEventListener("install", function (e) {
  e.waitUntil(
    caches.open(CACHE).then(function (c) {
      return Promise.all([
        fetch(PAGE, { cache: "reload" }).then(function (r) {
          if (!r.ok) throw new Error("page " + r.status);
          return savePage(r);
        }),
        Promise.all(ASSETS.map(function (u) {
          return fetch(new Request(u, { cache: "reload" })).then(function (r) { if (r.ok) return c.put(u, r); }).catch(function () {});
        })),
        fetch(LIB, { mode: "cors" }).then(function (r) { if (r.ok) return c.put(LIB, r); }).catch(function () {})
      ]);
    }).then(function () { return self.skipWaiting(); })
  );
});

self.addEventListener("activate", function (e) {
  e.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(keys.filter(function (k) { return k !== CACHE; })
                             .map(function (k) { return caches.delete(k); }));
    }).then(function () { return self.clients.claim(); })
  );
});

function staleWhileRevalidate(req) {
  return caches.open(CACHE).then(function (c) {
    return c.match(req, { ignoreSearch: true }).then(function (hit) {
      var net = fetch(req).then(function (r) {
        if (r && (r.ok || r.type === "opaque")) c.put(req, r.clone());
        return r;
      }).catch(function () { return hit || Response.error(); });
      return hit || net;
    });
  });
}

self.addEventListener("fetch", function (e) {
  var req = e.request;
  if (req.method !== "GET") return;
  var url = new URL(req.url);

  // পেজ খোলা: ক্যাশ থেকে সঙ্গে সঙ্গে (অফলাইনেও), পেছনে নতুন কপি এনে রাখা
  if (req.mode === "navigate") {
    e.respondWith(
      caches.match(PAGE).then(function (hit) {
        var net = fetch(PAGE, { cache: "no-cache" }).then(function (r) {
          if (r.ok) { savePage(r.clone()); }
          return clean(r);
        });
        if (hit) { net.catch(function () {}); return hit; }
        return net;
      })
    );
    return;
  }

  // নিজের আইকন/ম্যানিফেস্ট + সুপাবেস লাইব্রেরি
  if (url.origin === self.location.origin || url.hostname === "cdn.jsdelivr.net") {
    e.respondWith(staleWhileRevalidate(req));
  }
  // supabase.co এপিআই (লগইন/ডেটা) সরাসরি নেটওয়ার্কে যায়, ক্যাশ হয় না
});

// ── নোটিফিকেশন (সুপাবেসের send-reminders ফাংশন থেকে আসে) ──
self.addEventListener("push", function (e) {
  var d = {};
  try { d = e.data ? e.data.json() : {}; } catch (x) { try { d = { body: e.data.text() }; } catch (y) {} }
  e.waitUntil(self.registration.showNotification(d.title || "Hisab Khata", {
    body: d.body || "",
    icon: "./icon-192.png",
    badge: "./icon-192.png",
    tag: d.tag || "hisab",
    lang: d.lang || "bn",
    data: { url: d.url || "./" }
  }));
});

self.addEventListener("notificationclick", function (e) {
  e.notification.close();
  var target = new URL((e.notification.data && e.notification.data.url) || "./", self.registration.scope).href;
  e.waitUntil(self.clients.matchAll({ type: "window", includeUncontrolled: true }).then(function (list) {
    for (var i = 0; i < list.length; i++) {
      var c = list[i];
      if (c.url.indexOf(self.registration.scope) === 0) {
        return c.focus().then(function (w) { return (w || c).navigate(target); })
                        .catch(function () { return self.clients.openWindow(target); });
      }
    }
    return self.clients.openWindow(target);
  }));
});
